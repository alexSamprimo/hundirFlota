﻿using Coches.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Coches
{
    public partial class Form1 : Form
    {
        //declaro las variables globales para luego trabajar cone ellas

        int precioSalida, precioResult;
        string dni, nombre;
        DateTime f;
        public Form1()
        {
            InitializeComponent();
            //aqui hacemos las confguraciones de cada boton, lo que activa y desactiva cada uno
            if (rbSinPack.Checked)
            {
                cbClimatizador.Enabled = true;
                cbLlantas.Enabled = true;
                cbAsientos.Enabled = true;
                cbFaros.Enabled = true;
                cbGPS.Enabled = true;
            }

            if (rbCity.Checked)
            {
                cbClimatizador.Enabled = false;
                cbLlantas.Enabled = true;
                cbAsientos.Enabled = true;
                cbFaros.Enabled = true;
                cbGPS.Enabled = true;
            }

            if (rbTitanium.Checked)
            {
                cbClimatizador.Enabled = false;
                cbLlantas.Enabled = false;
                cbAsientos.Enabled = false;
                cbFaros.Enabled = true;
                cbGPS.Enabled = true;
            }

            if (rbSport.Checked)
            {
                cbClimatizador.Enabled = false;
                cbLlantas.Enabled = false;
                cbAsientos.Enabled = false;
                cbFaros.Enabled = false;
                cbGPS.Enabled = false;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //al iniciar el programa, se mostrara la foto del logo
            pbImagen.Image = Resources.ford_logo;
            //al inicio no se mostrara el precio del coche de salida ni el resultado
            lbPrecioSalida.Visible = false;
            lbResult.Visible = false;
        }

        private void cbModelo_SelectedIndexChanged(object sender, EventArgs e)
        {
            //aqui segun el modelo que se elija, se mostrara el precio inicial, y tambien se calculará el precio total, ademas de cambiar la imagen
            switch (cbModelo.Text)
            {
                case "KA":
                    pbImagen.Image = Properties.Resources.KA;
                    precioSalida = 8800;
                    //resultado();
                    lbPrecioSalida.Text = precioSalida.ToString();
                    lbPrecioSalida.Visible = true;
                    break;
                case "FIESTA":
                    pbImagen.Image = Properties.Resources.FIESTA;
                    precioSalida = 13975;
                    lbPrecioSalida.Text = precioSalida.ToString();
                    lbPrecioSalida.Visible = true;
                    //resultado();
                    break;
                case "C-MAX":
                    pbImagen.Image = Properties.Resources.B_MAX;
                    precioSalida = 18550;
                    lbPrecioSalida.Text = precioSalida.ToString();
                    lbPrecioSalida.Visible = true;
                    //resultado();
                    break;
                case "KUGA":
                    pbImagen.Image = Properties.Resources.KUGA;
                    precioSalida = 21750;
                    lbPrecioSalida.Text = precioSalida.ToString();
                    lbPrecioSalida.Visible = true;
                    //resultado();
                    break;
                case "MUSTANG":
                    pbImagen.Image = Properties.Resources.MUSTANG;
                    precioSalida = 39500;
                    lbPrecioSalida.Text = precioSalida.ToString();
                    lbPrecioSalida.Visible = true;
                    //resultado();
                    break;
                    
            }
        }
    }
}
